# Ingredient checklist

Check every page against the core ingredients, then the extras for that page type. Mark each ✅ has it (quote it), ⚠️ weak (quote it and say why) or ❌ missing.

## Core ingredients (every page)
- **Speaks to the right reader:** their problem, in their words, not expert jargon
- **Headline fits the reader:** story, result or named method, matched to how aware and how sceptical they are
- **Reciprocity:** gives something useful before asking
- **Liking:** sounds like a real person; a story with the struggle before the success; a real face
- **Authority:** named method, specific numbers, credibility in someone else's words (host, client, press, stage, books)
- **Social proof:** specific results from people like the reader (same job, same situation, same country); crowd numbers or reviews
- **Commitment:** small yeses before the big ask; one clear next step
- **Scarcity:** a true, specific reason to act now (only where it's real)
- **Unity:** "we", a name for their people, a shared mission or enemy
- **Emotion:** opens with pain or a recognisable situation, pulls forward with hope, closes with fear of loss or belonging
- **Order:** gift, liking and authority early; proof in the middle; scarcity near the end, never in the first screen

## Extras by page type

**Homepage**
- In the first screen: who it's for, the result, and one clear button
- Proof near the top (logos, numbers, a strong result)
- The founder's face and a short version of their story
- A free first step (lead magnet, class, quiz) for visitors not ready to buy

**About page**
- Their story: where they were, the low point, what changed, where they are now
- Why they're the right guide for this reader, not just a list of credentials

**Opt-in or registration page**
- A specific, useful promise for the free thing
- Who it's for and who it's not for
- Who's teaching, with credibility
- As few form fields as possible

**Thank-you page**
- What happens next, and when
- Add to calendar
- A small next yes (share, watch a short video, join a group)

**Webinar or masterclass**
- Teaches one real technique (no teaser)
- Story in the first ten minutes
- A live exercise and moments to say yes in the chat
- Student results from people like the audience
- A real deadline on the offer

**Sales page**
- Headline matched to the reader
- Their problem, then the vision, then the named method
- Proof from people like them, with numbers
- Who it's for and not for; the questions buyers ask, answered
- What's included, the price, and the guarantee in plain words
- A true reason to act now

**Checkout**
- A reminder of the result they're buying
- Proof and the guarantee next to the button
- Nothing that distracts

**Launch emails**
- Subject lines that make them curious or name their problem
- One idea per email, one clear link
- Story and proof across the sequence; real urgency only at the end
