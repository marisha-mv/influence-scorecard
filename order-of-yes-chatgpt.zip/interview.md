# Gap questions

Only ask what the pages didn't already show you. One or two at a time. Challenge vague answers before moving on.

## The gift (reciprocity)
- What's the most useful thing you could give away for free, something people would have paid for?
- Can they use it today and get a real result?

## You (liking)
- Where were you before you figured this out? What was the low point?
- What do you and your buyer have in common?
- What are you both against: an old way of doing things, a myth, an industry habit?

## Your credibility (authority)
- Does your method have a name? If not, what are its steps? Let's name it.
- What are your real numbers: clients, years, results, audience?
- Who could vouch for you: a host, a partner, a client, the press? Any stage photos, books or media?

## Your proof (social proof)
- Three client results. For each: who they were, what they did, what changed, with a number or a moment.
- Which client looks most like your buyer?
- Any reviews, ratings or a crowd number ("2,000 students")?

## The path to yes (commitment)
- What small step can someone take before buying: a free class, a quiz, a checklist, a call?
- What questions would your buyer nod "yes" to?

## Why now (scarcity)
- Is there a real reason to decide now: a start date, limited seats, a price that really goes up?
- What does waiting cost them?

## Their people (unity)
- What would your clients call themselves as a group?
- Where do they meet each other, not just you?

## The feelings (emotional triggers)
- What frustrates them most right now? (pain)
- What does life look like six months after working with you? (hope)
- What happens if they do nothing? (fear of loss)
- Who do they want to belong with, and who do they want to become? (belonging, status)
