# Playbook: how to do each ingredient well

Use this when an ingredient is ⚠️ weak or ❌ missing. Tailor it: use their business, their buyer and their real facts. Show the levels so they can see the gap, then give them a fill-in template and the steps to get there.

## Headline
- **Weak:** "Unlock your full potential." (could be anyone)
- **Good:** "Get your energy back in 21 days." (a clear result)
- **Great:** "The Cortisol Reset: why you're tired after 8 hours of sleep, and the 3-step fix." (a named method plus their exact situation)
- **How:** pick the type from the reader (story, result or method), use the buyer's words, add one specific (a number, a time frame, a named method), and cut every word that could appear on a competitor's page.
- **Templates:** "The [Named Method]: how [who] get [result] without [what they hate]." · "[Result] in [time frame], even if [their biggest doubt]." · "Do you [symptom they'll recognise]?"
- **Avoid:** clever wordplay, vague promises, jargon.

## Reciprocity (give first)
- **Weak:** "Sign up for my newsletter."
- **Good:** "Free checklist: 10 things to fix on your sales page."
- **Great:** "Free 30-minute class: the 3-step script I used to book 40 calls last month. Use it tomorrow."
- **How:** give one real result, not a teaser. Make it specific (what exactly, how long, what they'll be able to do). Make it personal where you can (a quiz or score with their own result). Keep giving after the sale (a surprise bonus, a check-in).
- **Templates:** "Free [format]: [specific result] you can use [today / tomorrow]." · "Get your personal [score / plan / report] in [3] minutes."
- **Avoid:** gifts that hold back the "how"; asking for the sale in the same breath.

## Liking (be someone they want to buy from)
- **Weak:** "Jane Smith, PhD, is a leading expert in…"
- **Good:** "I'm Jane. I help mums who are running on empty."
- **Great:** "Five years ago I was the mum snapping at her kids every evening. Here's what changed."
- **How:** tell the story in four beats (where I was, the low point, what changed, where I am now). Write the way they talk. Name what you have in common. Pick a shared enemy (a myth, an industry habit). Show a real face and real life.
- **Templates:** "[Time] ago I was [the low point they'll recognise]. Then I [discovered / tried] [what changed]. Now [result]." · "If you're tired of [shared enemy], you're in the right place."
- **Avoid:** a list of credentials instead of a person; a story that's all success and no struggle.

## Authority (show you really know this)
- **Weak:** "I'm an experienced coach."
- **Good:** "12 years, 600 clients."
- **Great:** "The Full Mat Method: used by 300 yoga studios. As featured on [real podcast or stage]." Introduced by someone else, not self-praise.
- **How:** name your method (and its steps). Swap adjectives for numbers. Get someone else to say it: a quote from a host, partner or client, or a "featured on" line, but only real ones. Show stage photos, books or titles if you have them. Keep every number identical across every page.
- **Templates:** "The [Named Method]: [number] steps to [result]." · "Used by [number] [who]." · "“[Quote]” — [Name], [role]."
- **Avoid:** self-praise ("world-class", "leading"); logos you can't stand behind; numbers that change from page to page.

## Social proof (people like them got results)
- **Weak:** "My clients love working with me!"
- **Good:** "“Great programme, highly recommend.” — Sarah"
- **Great:** "“I filled my Saturday class in 6 weeks.” Sarah K., yoga teacher, Leeds."
- **How:** collect results in three parts (who they were, what they did, what changed, with a number or a moment). Match proof to the reader (same job, same stage, same country). Put proof right next to every ask. Mix formats: a crowd number at the top, two or three specific stories in the middle, video if you have it.
- **Templates:** "“[Specific result] in [time].” [Name], [job], [place]." · "Join [number] [who] who've [result]."
- **To collect proof:** send past clients three questions: "Where were you before?", "What did you do?", "What changed? Give me a number or a moment."
- **Avoid:** vague praise; proof from people who don't look like the buyer; made-up or "composite" testimonials.

## Commitment (small yeses first)
- **Weak:** "Buy now."
- **Good:** "Book a free call."
- **Great:** "Does this sound like you? If you nodded at two of these, keep reading." Then a short quiz, then a free class, then the offer.
- **How:** add a "Does this sound like you?" checklist. Make the first step tiny (one field, one click). Ask questions they'll say yes to. Add a calendar invite after sign-up. In webinars, ask for a "type YES" and a live exercise before the offer.
- **Templates:** "Does this sound like you? □ [problem 1] □ [problem 2] □ [problem 3]" · "Start with [tiny free step]."
- **Avoid:** going from a stranger straight to a big ask; long forms on the first step.

## Scarcity (a true reason to act now)
- **Weak:** "HURRY! Limited time only!!!"
- **Good:** "Doors close Friday."
- **Great:** "Doors close Friday at midnight (UK time). The next group starts in March, at the new price. I keep it to 30 people so I can review every plan personally."
- **How:** give the real reason it's limited (your time, a live cohort, a real price change). Name an exact date and time. Say what waiting costs them in their terms (another month of the same results). Put it near the end, after the value and proof. Keep your word, every time.
- **Templates:** "[Doors close / Price goes up] [day] at [time]. [Real reason]." · "I take [number] [clients / students] [per month / per group] because [real reason]."
- **Avoid:** countdowns that reset; "only 3 spots left" that's always 3; discounts that never really end. Sophisticated buyers notice, and it costs trust.

## Unity (they're one of us)
- **Weak:** "Our customers get access to resources."
- **Good:** "Join our community."
- **Great:** "Welcome to the Rebels: 4,000 founders who refuse to burn out."
- **How:** give your people a name. Write "we" and "people like us." Name what you stand for and against together. Give them a place to meet each other, and celebrate their wins in public.
- **Templates:** "Join [number] [name for your people] who [shared belief]." · "People like us don't [shared enemy]."
- **Avoid:** calling them "customers" or "users" in your copy.

## Emotion
- **How:** open with pain or a situation they recognise, pull forward with hope (a concrete picture of life after), close with fear of loss or belonging.
- **Template for hope:** "Picture [specific moment in their life after the result]."
