# Toolkit: ways to apply each principle, with real examples

Use these to suggest specific fixes. Cite the example when it helps the person picture it.

## Reciprocity: give before you ask
- A free class that teaches a real technique (Mindvalley's free masterclasses; at the end people can choose to join)
- Free long-form content (Alex Hormozi's hours of free teaching on YouTube, followed by invitations to paid offers)
- A free tool or personal result (HubSpot's Website Grader; 16Personalities' free report)
- A surprise after the sale (Zappos' free shipping upgrades)
- Evidence: a free gift of personalised address labels lifted responses to a Disabled American Veterans donation letter from 18% to 35% (Cialdini, Influence). A waiter's unexpected second mint raised tips 23% (Strohmetz et al., 2002).

## Liking: be someone they want to buy from
- Show your cracks: the struggle before the success (Brené Brown's vulnerability talk)
- Origin story, especially being an outsider or the first in your family (Sara Blakely selling fax machines before Spanx)
- Humour (Dollar Shave Club's $4,500 video: 12,000 orders in 48 hours)
- A shared enemy (Vishen's "Brules": the outdated rules we never chose)
- Use their name; show your real life; a real face on the page
- Evidence: Highrise roughly doubled paid signups with a big photo of a smiling customer (37signals). Negotiators who chatted first were about four times as likely to agree (Morris, Nadler et al., 2002).

## Authority: make your expertise visible
- Specific numbers ("312 clients", not "many clients")
- Stage photos, media logos, books and titles
- A named method (Silva Ultramind, 6 Phase Meditation, the KonMari Method)
- Be introduced by someone else (host, partner, podcast)
- Borrowed authority (MasterClass with Gordon Ramsay)
- Evidence: one sentence introducing an agent's 15 years of experience raised appointments about 20% (Cialdini). Ogilvy's Rolls-Royce headline, taken from a motoring expert's review, preceded a 50% sales rise.

## Social proof: people like them got results
- Specific testimonials: who they were, what they did, what changed
- Crowd numbers ("Join 40,000 students"), ratings, badges, top lists
- Proof that matches the reader: same job, same situation, same country
- Live activity and live chat reactions
- Evidence: products with five reviews were 270% more likely to be bought than products with none, more so for expensive items (Spiegel Research Center, Northwestern).

## Commitment: small yeses first
- Questions they'll nod to; checklists ("if two of these sound like you…")
- Quizzes before the offer (Noom)
- One-click registration, calendar invites, "type YES" in a live class, a live exercise
- Streaks and daily habits (Duolingo: a 7-day streak makes learners 3.6× more likely to finish)
- Evidence: people who agreed to a tiny window sign were far more likely to later accept a large lawn sign: 76% vs 17% (Freedman & Fraser, 1966).

## Scarcity: a true reason to act now
- Real cart close with a date and time; early-bird prices that really rise
- Seats capped at what you can truly deliver; waitlists
- Exclusive information
- Never a fake or resetting timer
- Evidence: buyers told beef would be scarce bought twice as much; told it as exclusive information, six times as much (Cialdini, Influence).

## Unity: they're one of us
- A name for your people (Swifties, Beauty Insiders)
- "We" and "people like us"; insider language (CrossFit's "box" and "WOD")
- A shared mission or shared enemy (Patagonia)
- Places to meet and milestones to celebrate (Harley Owners Group, Peloton)
- Evidence: Sephora's Beauty Insider community has 45 million members in North America and drives the majority of Sephora's sales.
