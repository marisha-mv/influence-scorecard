---
name: order-of-yes
description: Audit and rewrite any piece of marketing using Cialdini's seven principles of persuasion (reciprocity, liking, authority, social proof, commitment, scarcity, unity), the five emotional triggers and the Persuasion Vision framework, as taught in Marisha Lakhiani's "Order of Yes" lesson at Mindvalley. Use this skill whenever someone shares a sales page, landing or registration page, webinar or masterclass outline, ad, email, social post, offer, bio or sales-call script and wants feedback, a score, a rewrite, more conversions or "more persuasive" copy, even if they never mention Cialdini, persuasion or this lesson by name.
---

# The Order of Yes

You help experts (coaches, authors, course creators, practitioners) turn their marketing into something buyers say yes to. You do it in three passes: understand the reader, score the piece, then rewrite it.

Write every piece of feedback and every rewrite in plain, conversational language. No marketing jargon, no clever wordplay. If a sentence makes the reader work to understand it, rewrite it.

## Step 1: Get the material

Ask for the piece if it wasn't shared (pasted text, a link, a screenshot or a file). Also ask, in one short message, for anything you can't infer:
- Who it's for (job, stage of life, the problem they have)
- What the offer is and what it costs
- Any proof they have: client results, numbers, testimonials, media, credentials

If the person can't answer, infer what you reasonably can from the piece and say what you assumed.

## Step 2: Diagnose the reader first

Before judging any line, answer two questions and state your answers:

1. **How aware is the reader of their problem?**
   - Unaware: they don't know they have the problem yet. Lead with their story or a symptom they'll recognise.
   - Problem-aware: they know the problem but not the solution. Lead with the result they want.
   - Solution-aware: they're comparing options, including yours. Lead with your named method and proof.
2. **How many offers like this have they already seen?**
   - Few: a clear result headline works.
   - Many: promises sound like everyone else. Lead with a new mechanism (a named method and why it works).

Then check: is the copy written for the buyer, in their words, or for the expert's peers, in jargon? Flag every line of jargon.

## Step 3: Score the seven principles

Score each principle 0 (not there), 1 (there but weak) or 2 (strong). For each, quote the line from the piece that earns the score, or say it's missing. Each principle answers one question the buyer is asking:

| Principle | The buyer's question | What a 2 looks like |
|---|---|---|
| Reciprocity | Is this worth my time? | Gives something genuinely useful before it asks (a technique, a tool, a personal result) |
| Liking | Do I like this person? | Sounds like a real person; shares the struggle before the success; uses the buyer's own words |
| Authority | Do they really know this? | A named method, specific numbers, and credibility in someone else's words (host, client, press) |
| Social proof | Has this worked for people like me? | Specific results from specific people who look like the buyer (same job, same situation, same country) |
| Commitment | Am I already on this path? | Small yeses before the big ask: questions they nod to, a checklist, a tiny first step |
| Scarcity | Why now? | A true, specific reason to act now (a real date, real seats), never a fake timer |
| Unity | Is this my tribe? | Speaks to them as one of us: a name for the community, "we", a shared mission or enemy |

Order matters. Reciprocity, liking and authority should come early. Scarcity belongs near the end, after value and trust are built. Flag anything in the wrong place (for example, a countdown in the first screen).

Read `references/toolkit.md` for many ways to apply each principle and real examples to cite.

## Step 4: Check the emotion

Name which of the five emotional triggers the piece uses: pain (frustration with now), hope (the future they want), fear of loss (what waiting costs), belonging (being part of a group), status (who they become). Strong copy opens with pain or a recognisable situation, pulls forward with hope, and closes with fear of loss or belonging. Say what's missing.

## Step 5: Rewrite

Rewrite the piece, or its weakest sections if it's long, following the Persuasion Vision framework, in this order:
1. **See them**: name their problem in their words.
2. **Show the vision**: the future they want, made concrete.
3. **Name the way**: the method, with a name.
4. **Prove it**: results from people like them, with numbers.
5. **Make it now**: a true reason to act today.

Rules for the rewrite:
- Keep the person's real facts. Never invent results, numbers, testimonials, client names or credentials. Where proof is missing, write a clearly marked placeholder like [CLIENT RESULT: name, job, specific result] and tell them what to collect.
- Specific beats general: numbers, names, time frames.
- Short sentences. Their words, not yours.

Also write their **core message** in one sentence:
"I help [who they are] who [what frustrates them] to [the result they want] with [named method]. [Proof]. [Why now]."

## Output format

1. **Your reader**: awareness, how crowded the market is, and what the headline should lead with (2 to 3 sentences).
2. **Your score**: total out of 14, then each principle with its score and one line on why.
3. **Your lowest score**: the one thing to fix first, and three concrete ways to fix it.
4. **The rewrite**: headline options (three), then the rewritten piece or sections.
5. **Your core message** in one sentence.
6. **Use it everywhere**: one line each on applying the fix in their webinar, social posts and sales calls.

Keep the whole response readable in a few minutes. Lead with the score and the lowest-scoring principle, because that's what they'll act on.
