# The interview

Ask in this order. One or two questions at a time. Skip anything the page already answers clearly, and tell them you're skipping it because it's already strong. After every answer, challenge anything vague before moving on.

## 1. The reader
- Who exactly is this page for? Describe one real person you'd love to work with: their job, their situation, what a bad day looks like for them.
- How would they describe their problem to a friend, in their own words?
- Do they know they have this problem yet, or do you have to show them?
- How many offers like yours have they already seen? Are they tired of promises?

## 2. The gift (reciprocity)
- What's the most useful thing you could give them for free, something they'd have paid for?
- Can they use it today and get a real result?

## 3. You (liking)
- Where were you before you figured this out? What was the low point?
- What do you and your buyer have in common?
- What are you both against? (An old way of doing things, a myth, an industry habit.)

## 4. Your credibility (authority)
- Does your method have a name? If not, what are its steps? Let's name it.
- What are your real numbers: clients, years, results, audience?
- Who could say good things about you: a host, a partner, a client, the press? Any stage photos, books, media?

## 5. Your proof (social proof)
- Give me three client results. For each: who they were, what they did, what changed, with a number or a moment.
- Which of those clients looks most like the person this page is for?
- Do you have reviews, ratings, a crowd number ("2,000 students")?

## 6. The path to yes (commitment)
- What small step could someone take before buying: a free class, a quiz, a checklist, a call?
- What questions would your buyer nod "yes" to?

## 7. Why now (scarcity)
- Is there a real reason to decide now: a start date, limited seats, a price that really goes up? What's the honest reason?
- What does waiting cost them?

## 8. Their people (unity)
- What would your clients call themselves as a group?
- Where do they meet each other, not just you?

## 9. The feelings (emotional triggers)
- What frustrates them most right now? (pain)
- What does life look like six months after working with you? (hope)
- What happens if they do nothing? (fear of loss)
- Who do they want to belong with, and who do they want to become? (belonging, status)

When you have enough to rewrite well, say so and move to the rewrite. Don't drag the interview out.
